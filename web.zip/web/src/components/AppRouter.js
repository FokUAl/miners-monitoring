import React from 'react'
import {Switch, Route, Redirect} from 'react-router-dom'

export const AppRouter = () => {
    return (
        <div>

        </div>
    )
}