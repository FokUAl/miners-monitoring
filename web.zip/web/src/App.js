import AppRouter from './AppRouter'
import "./scss/app.scss"

function App() {
  return (
    <div className="App">
      <AppRouter />
      

    </div>
  );
}

export default App;
